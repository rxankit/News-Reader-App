module.exports = {
  presets: ['metro-react-native-babel-preset'],
};
